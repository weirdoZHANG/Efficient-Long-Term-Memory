import torch
from torch import nn, optim
import pandas as pd
from os.path import join
from typing import Optional
from sklearn.preprocessing import StandardScaler
from torch.utils.data import Dataset, DataLoader

# Setup device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Get ILI data and more
df_raw = pd.read_csv(join('storage/datasets', 'exchange_rate/exchange_rate.csv'))
cols = list(df_raw.columns)
cols.remove('date')
data = df_raw[cols]
input_size = len(cols)
output_size = len(cols)

# data standardization
split_ratio = 0.7
split_index = int(len(data) * split_ratio)
train_data = data[:split_index]

scaler = StandardScaler()
scaler.fit(train_data.values)
data_normalized = scaler.transform(data.values)

# Set window size
lookback_len = 96
horizon_len = 720  # 36/48/60 or other

# Data set segmentation
train_sequence = data_normalized[:split_index]
test_sequence = data_normalized[split_index - lookback_len:]

# Define a timing data set
class TrainDataset(Dataset):
    def __init__(self, train_data):
        self.train_data = train_data

    def __len__(self):
        return len(self.train_data) - lookback_len - horizon_len + 1

    def __getitem__(self, idx):
        data_x = torch.tensor(self.train_data[idx:idx+lookback_len], dtype=torch.float).view(-1, input_size)
        data_y = torch.tensor(self.train_data[idx+lookback_len:idx+lookback_len+horizon_len], dtype=torch.float).view(-1, input_size)
        return data_x, data_y

# Create training sets and test sets
train_dataset = TrainDataset(train_sequence)
test_dataset = TrainDataset(test_sequence)

# Create a DataLoader instance or other
batch_size = 256
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, drop_last=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, drop_last=False)

# Efficient Long Term Memory: ELTM
class ELTMcell(nn.Module):
    def __init__(self, input_size: int, hidden_size: int):
        super(ELTMcell, self).__init__()
        # Reset the input weight matrix initialization
        self.input_in = nn.Linear(input_size, hidden_size * 2, bias=False)
        self.hidden_in = nn.Linear(hidden_size, hidden_size * 2)
        self.only_x = nn.Linear(input_size, hidden_size, bias=False)
        self.only_h = nn.Linear(hidden_size, hidden_size, bias=False)

        # Update the output weight matrix initialization
        self.input_out = nn.Linear(hidden_size, hidden_size, bias=False)
        self.hidden_out = nn.Linear(hidden_size, hidden_size, bias=False)
        self.candidate_hidden_out = nn.Linear(hidden_size, hidden_size)
        # Branch output parameter initialization
        self.alpha_p = nn.Linear(hidden_size, hidden_size, bias=False)
        self.beta_p = nn.Linear(hidden_size, hidden_size, bias=False)
        # gamma(γ): γ=1-(α*o_gate+β*o_gate),  γ=o_gate*gamma_p, (α_p+β_p+γ_p) = o_gate^(-1)

    def forward(self, x: torch.Tensor, hidden: torch.Tensor):
        # Combined reset input
        input_gates = self.input_in(x) + self.hidden_in(hidden)
        i_gate, h_gate = input_gates.chunk(2, dim=-1)
        i_gate = torch.sigmoid(i_gate)  # Candidate reset input gate
        h_gate = torch.tanh(h_gate)  # Candidate hidden state
        ch_n = i_gate * h_gate  # Reset hidden state

        # Separate reset input
        only_x_gate = self.only_x(x)
        x = torch.tanh(only_x_gate)
        only_h_gate = self.only_h(hidden)
        hidden = torch.tanh(only_h_gate)

        # Update output
        output_gates = self.input_out(x) + self.hidden_out(hidden) + self.candidate_hidden_out(ch_n)
        o_gate = torch.sigmoid(output_gates)  # Update output gate
        alpha = self.alpha_p(o_gate)  # Update individual inputs
        beta = self.beta_p(o_gate)  # Update separate past hidden states
        gamma = 1 - alpha - beta  # Update the current candidate hidden state
        h_next = alpha * x + beta * hidden + gamma * ch_n  # The final hidden state output

        return h_next

# multilayer ELTM
class ELTM(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, num_layers: int):
        super(ELTM, self).__init__()
        self.num_layers = num_layers
        self.hidden_size = hidden_size
        # Create multiple EltMcells, with the first layer special
        self.ELTMs = nn.ModuleList([ELTMcell(input_size, hidden_size)] +
                                   [ELTMcell(hidden_size, hidden_size) for _ in range(num_layers - 1)])

    def forward(self, x: torch.Tensor, state: Optional[torch.Tensor] = None):
        # Output shape of x: [seq_len. batch_size, input_size]
        # state is hidden(h): [batch_size, hidden_size]
        seq_len, batch_size = x.shape[:2]

        # Collect the output for each time step
        if state is None:
            hidden = [x.new_zeros(batch_size, self.hidden_size) for _ in range(self.num_layers)]
        else:
            (hidden) = state
            hidden = list(torch.unbind(hidden))

        # Collect the output for each time step
        out = []
        for t in range(seq_len):
            # The input at the first moment is x itself
            inp = x[t]
            # Traverse n layers
            for layer in range(self.num_layers):
                hidden[layer] = self.ELTMs[layer](inp, hidden[layer])
                # Take the output of the current layer as the input of the next layer
                inp = hidden[layer]
            # Collect the last minute output
            out.append(hidden[-1])

        # Overlay all outputs together
        out = torch.stack(out)
        hidden = torch.stack(hidden)
        return out, hidden

class ELTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(ELTMModel, self).__init__()
        self.eltm = ELTM(input_size, hidden_size, num_layers=1)
        self.linear1 = nn.Linear(lookback_len, horizon_len)
        self.linear2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.eltm(x)
        out = torch.transpose(out, 2, 1)
        out = self.linear1(out)
        out = torch.transpose(out, 2, 1)
        out = self.linear2(out)
        return out

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers=1, batch_first=True)
        # self.gru = nn.GRU(input_size, hidden_size, num_layers=1, batch_first=True)
        self.linear1 = nn.Linear(lookback_len, horizon_len)
        self.linear2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.lstm(x)
        # out_gru, _ = self.gru(x)
        out = torch.transpose(out, 2, 1)
        out = self.linear1(out)
        out = torch.transpose(out, 2, 1)
        out = self.linear2(out)
        return out

class GRUModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(GRUModel, self).__init__()
        self.gru = nn.GRU(input_size, hidden_size, num_layers=1, batch_first=True)
        self.linear1 = nn.Linear(lookback_len, horizon_len)
        self.linear2 = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        out, _ = self.gru(x)
        out = torch.transpose(out, 2, 1)
        out = self.linear1(out)
        out = torch.transpose(out, 2, 1)
        out = self.linear2(out)
        return out

# create models
# model = ELTMModel(input_size=input_size, hidden_size=64, output_size=output_size).to(device)
model = LSTMModel(input_size=input_size, hidden_size=64, output_size=output_size).to(device)
# model = GRUModel(input_size=input_size, hidden_size=64, output_size=output_size).to(device)

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)
num_epochs = 200  # or other

for epoch in range(num_epochs):
    total_loss = 0
    for data_x, data_y in train_loader:
        data_x, data_y = data_x.to(device), data_y.to(device)
        optimizer.zero_grad()

        y_pred = model(data_x)

        loss = criterion(y_pred, data_y)
        total_loss += loss.item()
        loss.backward()
        optimizer.step()

    print(f'Epoch {epoch + 1}/{num_epochs}, MSE: {total_loss}')

# Define model evaluation functions
def evaluate_model(model, test_loader, criterion):
    model.eval()
    total_loss = 0
    with torch.no_grad():
        for data_x, data_y in test_loader:
            data_x, data_y = data_x.to(device), data_y.to(device)

            y_pred = model(data_x)
            loss = criterion(y_pred, data_y)
            total_loss += loss.item()
    return total_loss

test_mse = evaluate_model(model, test_loader, criterion)
print(f'Model Test MSE: {test_mse}')
